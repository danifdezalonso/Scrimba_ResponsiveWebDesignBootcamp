# Responsive Web Design Bootcamp | Scrimba course files
Course files for the Responsive Web Design Bootcamp: https://scrimba.com/course/gresponsive/

All files start at the same place as the first video of the project. It includes all images, plus a starting HTML and CSS files.

## The normailze.css files
You will also notice all the project foldes includes a `normalize.css` file. 

Scrimba includes this by default, behind the scenes. You'll want to leave this in each project file, and keep the link in the HTML file.
By default, Scrimba places them in the root folder. If you'd prefer to stay organized, feel free to move it to the CSS folder, but ensure that you also update the path in all the HTML files if you do this :).
